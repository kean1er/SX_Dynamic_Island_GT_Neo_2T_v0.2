# SX Dynamic Island — Realme GT Neo 2T source prototype v0.2

Phone targeting: Realme GT Neo 2T, Realme UI 4.0 (Android 13 family), 1080×2400 display with top-left punch-hole.

## Included
- Overlay pill, placed at upper-left with initial estimated offsets
- Live HH:mm clock within capsule
- Battery percentage receiver
- Tap capsule to expand/collapse a basic card
- App screen to grant overlay permission and start/stop the service

## Caveats
This is Android Studio source, not a compiled APK. The Android SDK is not present in the authoring environment, so it has not been built or tested on a physical device.
Position values x=10dp/y=7dp are initial estimates and may need calibration with your display scaling.
An ordinary overlay cannot reposition Realme's native status-bar clock. The app renders its own clock in the capsule; native status-bar reflow would need deeper system UI modification.
Notification access, full media-session actions, timer, charging-specific animation, and configurable themes are not yet included in this starter.

## Build
Open this folder in Android Studio, sync Gradle, and choose Build > Build APK(s). Then install the debug APK on the phone and allow “Display over other apps”.
