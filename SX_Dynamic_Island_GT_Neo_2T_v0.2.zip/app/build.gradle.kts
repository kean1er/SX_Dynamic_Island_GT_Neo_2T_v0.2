plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.sx.island"
    compileSdk = 35
    defaultConfig { applicationId = "com.sx.island"; minSdk = 26; targetSdk = 32; versionCode = 2; versionName = "0.2" }
}
