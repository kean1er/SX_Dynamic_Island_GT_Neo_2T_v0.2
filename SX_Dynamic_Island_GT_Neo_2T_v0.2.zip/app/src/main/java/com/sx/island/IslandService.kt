package com.sx.island

import android.app.Service
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IslandService : Service() {
 private lateinit var wm:WindowManager
 private var capsule:LinearLayout?=null
 private var expanded=false
 private val handler=android.os.Handler()
 private var batteryPct=""

 private val tick=object:Runnable {
  override fun run() {
   capsule?.findViewWithTag<TextView>("clock")?.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date())
   capsule?.findViewWithTag<TextView>("battery")?.text=batteryPct
   handler.postDelayed(this,1000)
  }
 }
 private val batteryReceiver=object:BroadcastReceiver() {
  override fun onReceive(context:Context?,intent:Intent?) {
   val level=intent?.getIntExtra("level",-1) ?: -1
   val scale=intent?.getIntExtra("scale",-1) ?: -1
   if(level>=0 && scale>0) batteryPct="🔋 ${level*100/scale}%"
  }
 }

 override fun onCreate() {
  super.onCreate()
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  registerReceiver(batteryReceiver,IntentFilter(Intent.ACTION_BATTERY_CHANGED))
  val view=LinearLayout(this).apply {
   orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(13,7,13,7)
   background=GradientDrawable().apply { setColor(Color.BLACK); cornerRadius=60f }
   setOnClickListener { toggleExpanded() }
  }
  val cam=TextView(this).apply { text="●"; textSize=10f; setTextColor(Color.GRAY); setPadding(0,0,7,0) }
  val brand=TextView(this).apply { text="SX"; textSize=12f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD }
  val spacer=android.view.View(this)
  val clock=TextView(this).apply { tag="clock"; textSize=12f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD }
  val batt=TextView(this).apply { tag="battery"; textSize=11f; setTextColor(Color.WHITE); setPadding(8,0,0,0) }
  view.addView(cam); view.addView(brand); view.addView(spacer,LinearLayout.LayoutParams(10,1)); view.addView(clock)
  capsule=view
  val p=WindowManager.LayoutParams(
   WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
   WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
   WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
   android.graphics.PixelFormat.TRANSLUCENT
  ).apply {
   gravity=Gravity.TOP or Gravity.LEFT
   // Starting estimate for GT Neo 2T; user can fine-tune for display scaling and cutout margins.
   x=10; y=7
  }
  wm.addView(view,p)
  handler.post(tick)
 }

 private fun toggleExpanded() {
  expanded=!expanded
  capsule?.let { v ->
   v.removeAllViews()
   val title=TextView(this).apply {
    text=if(expanded) "SX   •   ${batteryPct.ifBlank { "Island active" }}   •   Tap to close" else "●   SX"
    textSize=12f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD
   }
   v.addView(title)
   val params=v.layoutParams as WindowManager.LayoutParams
   params.width=if(expanded) dp(245) else WindowManager.LayoutParams.WRAP_CONTENT
   params.height=dp(if(expanded) 48 else 32)
   wm.updateViewLayout(v,params)
  }
 }
 private fun dp(value:Int)= (value*resources.displayMetrics.density).toInt()
 override fun onDestroy() {
  handler.removeCallbacks(tick)
  try { unregisterReceiver(batteryReceiver) } catch (_:Exception) {}
  capsule?.let { if(it.isAttachedToWindow) wm.removeView(it) }
  capsule=null; super.onDestroy()
 }
 override fun onBind(intent:Intent?):IBinder?=null
}
