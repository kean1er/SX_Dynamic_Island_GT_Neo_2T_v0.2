package com.sx.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,48,32,32) }
  root.addView(TextView(this).apply { text="SX Dynamic Island\nRealme GT Neo 2T · UI 4.0"; textSize=23f })
  root.addView(TextView(this).apply {
   text="Prototype placement is upper-left to align with the phone's punch-hole camera. Grant overlay access, then start the island. Tap the capsule to expand/collapse."
   textSize=16f; setPadding(0,20,0,20)
  })
  root.addView(Button(this).apply { text="Allow display over apps"; setOnClickListener {
   startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
  }})
  root.addView(Button(this).apply { text="Start island"; setOnClickListener {
   if(Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity,IslandService::class.java))
   else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
  }})
  root.addView(Button(this).apply { text="Stop island"; setOnClickListener { stopService(Intent(this@MainActivity,IslandService::class.java)) }})
  setContentView(root)
 }
}
